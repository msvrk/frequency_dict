"""frequency_dict is a python package that helps with the finding the frequency of items in a collection easily"""

from .frequency_dict_from_collection import (
    frequency_dict_from_collection,
)
