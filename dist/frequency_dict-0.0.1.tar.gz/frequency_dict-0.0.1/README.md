# frequency_dict
A method to directly convert a collection of items to a frequency dictionary
